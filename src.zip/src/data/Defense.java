package data;

public class Defense {
	
	private double minDefense;
	private double maxDefense;
	
	
	public Defense() {
		
	}
	
	public double getMinDefense() {
		return minDefense;
	}
	public double getMaxDefense() {
		return maxDefense;
	}
	
	public void setMinDefense(double defense) {
		minDefense = defense;
	}
	public void setMaxDefense(double defense) {
		maxDefense = defense;
	}

}
