package data;

public class Food {
	
	private int maxFoodValue;
	private int foodValue;
	
	public Food() {
		
	}
	
	public int getFoodValue() {
		return foodValue;
	}
	public int getMaxFoodValue() {
		return maxFoodValue;
	}
	
	public void setFoodValue(int FoodValue) {
		foodValue = FoodValue;
	}
	public void setMaxFoodValue(int FoodValue) {
		maxFoodValue = FoodValue;
	}

}